#include <stdio.h>

void clear_machine();
int stateM_SET(char state);
int stateM_UA(char state);
int state_conf_SET(unsigned char buf[], int res);
int state_conf_UA(unsigned char buf[], int res);

