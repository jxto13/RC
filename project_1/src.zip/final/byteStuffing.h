

unsigned char* byte_stuff(unsigned char* input_data, int size, int* stuff_data_size);

unsigned char* byte_destuff(unsigned char* input_data, int input_data_size, int* stuff_data_size);
