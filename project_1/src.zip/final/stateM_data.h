int stateM_data(unsigned char* frame, int data_size, int frame_size);
unsigned char BCC2_calculation(unsigned char* data,int size);